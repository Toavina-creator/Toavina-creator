GROUND HANDLING OFFLINE ANDROID APP
===================================

This is an Android Studio project wrapping the offline manual browser in a native Android WebView.
The manual and its extracted searchable text are bundled in the app, so normal use does not need internet.

IMPORTANT
- This package is Android source code, not a compiled APK.
- This environment does not have the Android SDK/Gradle installed, so I could not compile and test an APK here.
- A GitHub Actions workflow is included to build the APK automatically.

BUILD THE APK WITH GITHUB ACTIONS
1. Extract this ZIP on a computer.
2. Create a new empty repository on GitHub.
3. Upload the contents of this folder to the repository (keep the .github folder).
4. Open the repository's Actions tab.
5. Select "Build Android APK", then click "Run workflow" (or push to main).
6. When the workflow finishes, open the run and download the artifact named
   "Ground-Handling-Offline-APK". Inside is app-debug.apk.
7. Transfer app-debug.apk to your Android phone and open it to install.
   Android may ask you to allow installation from that file manager/browser.

APP CONTENTS
- Offline manual search and section navigation
- Bundled original PDF for reference
- No network permission is requested by the app

Operational safety: this app packages the supplied manual only. Verify that it is the latest authorised revision before using it for operational decisions.
